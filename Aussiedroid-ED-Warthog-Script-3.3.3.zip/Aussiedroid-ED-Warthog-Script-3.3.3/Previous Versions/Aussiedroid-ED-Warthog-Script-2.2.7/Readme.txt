//--------------------------------------------------------------------------------------------------------------------------------------------------------------//
// AUSSIEDROID'S ACKNOWLEDGEMENTS //																		
//--------------------------------------------------------------------------------------------------------------------------------------------------------------//
// Standing on the Shoulders of Giants! Creation of this TARGET Script would not have been possible without amazing ED Scripts I found online created by:		//
// Alexandr Zhevedenko, Michael Lehman (WraithMG11235) & Darkcyde0.	You All Rock! Thank you!										
//--------------------------------------------------------------------------------------------------------------------------------------------------------------//
// VERSION HISTORY //																				
//--------------------------------------------------------------------------------------------------------------------------------------------------------------//
// Version 2.2																					// Released September, 2016	(Updated Jan 17)															
// =============================================================================================================================================================//
// v2.2.7-Fixes: Dead Throttle on Run/Looping running in Script Editor/Improved FPS/Bandwidth Toggle/Galaxy Map chat conflict. New: Heatsink+SilentRunning Mod! //
// v2.2.6-Changed SRV Digital Steering Hat Switch, Swapped Weapon Fire Group. Add Auto-Dock Short/Long press+Pinky. No Shadowplay ref. Add Fighter Orders.	//
// v2.2.5-Added Charge ECM button & Fixed Incorrect ED Bindings file in download.										//
// v2.2.4-Fixes: Changed Combo Fire Modifier from Pinky to CMS Hat Switch (avoid conflict). Improved PIP timings/refined layout. Removed SRV Handbrake conflict.//
// v2.2 - Guardians Update: Added Fighters Hotkeys to Trim Hat, Mapped Weapon/Engine Color change. Improved IDLE saftey features. New Macros. Public Release! 	//
// v2.1 - Added External Keymappings for TrackIR, VoiceAttack & ShadowPlay. Swapped Landing Gear & Silent Running. Changed some delay times.			//
// v2.0 - Full script cleanup & formatting update. Added alt. Macros for PIPs & Curves to test. Added Reference table for DX Mappings & USB Key Definitions.	//
// v1.8 - Added SetThrottle function & Handbrake to Throttle IDLE lock. Ship Lights now dim Throttle LED backlight :) Steam added & Hidden FPS/Ping keys mapped.//
// v1.6 - Improved Toggle switch usage. Added LED output & expanded script print output in Script Editor.							//
// v1.3 - Added Auto-dock, PIPs Macros & also Joystick & Throttle Curve presets. Plus Subsystem Prev Jump to Powerplant shortcut when holding Prev Subsystem.	//
// v1.0 - Added All Standard KeyMaps, Default Axis settings & Core script structure/defaults. Added Trigger Combo code. Debug testing.				//		
// =============================================================================================================================================================//
// Created by Aussiedroid (http://steamcommunity.com/id/aussiedroid/)														// Full Guide Available here (http://steamcommunity.com/sharedfiles/filedetails/?id=769637037)											//																						// Need help understanding this script?																	
// Target Script Editor Manual URL: http://ts.thrustmaster.com/download/accessories/pc/hotas/software/TARGET/TARGET_Script_Editor_Basics_v1.5_ENG.pdf			//
// 																					
//--------------------------------------------------------------------------------------------------------------------------------------------------------------//

Upgrading from a previous version?

Simply copy the new files to the appropriate locations below. Each version is numbered to ensure you don't override older settings.


Installation:
=============
Extract the zip file pack.

The Warthog Script can be run from any location. All files need to be in the same folder though. 

Just drag & drop to TARGET Script Editor & Run. Default script path can also be set in the options.

Most commands can be tested prior to starting the game using the Event Tester & Device Analyzer.

Copy the Elite Dangerous Profile to:
C:\Users\<User>\AppData\Local\Frontier Developments\Elite Dangerous\Options\Bindings

Copy the TrackIR Profile to:
(64bit). C:\Program Files (x86)\NaturalPoint\TrackIR5\Profiles
(32bit). C:\Program Files\NaturalPoint\TrackIR5\Profiles

Note: If the profile does not show up in TrackIR after copying to the above location (and restart TrackIR software didnt help), try copying the profile to:

C:\Users\<User>\AppData\Roaming\NaturalPoint\TrackIR 5\Profiles

Set the hotkeys in TrackIR; Pause Key to PAUSE, and Center to END.

Also set NVidia Shadowplay Capture Last 20mins hotkey to ALT+F11 (as required).

Map any other 3rd Party Keys such as Voice Comms (as required).

Always make sure the script is running as well as any other 3rd party tools prior to starting Elite Dangerous.

"I am a leaf on the wind!"